import React from 'react';
import './index.css';
import Lista from './Components/Lista';

function App() {
  return (
    <div className="App">
      <Lista />
    </div>
  );
}

export default App;
