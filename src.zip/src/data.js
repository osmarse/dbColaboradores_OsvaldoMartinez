export const dataInicial = [
    {
        id: "1",
        nombre: "Fernanda Martinez",
        correo: "fernanda@doctormac.cl"
    },
    {
        id: "2",
        nombre: "Valentina Martinez",
        correo: "valentina@doctormac.cl"
    },
    {
        id: "3",
        nombre: "Sebastian Martinez",
        correo: "sebastian@doctormac.cl"
    }
]